<?php
session_start();

if (isset($_SESSION['usuario']) && isset($_SESSION['correo']) && isset($_SESSION['contrasena'])) {
    $id_usuario = $_SESSION['id'];
    $usuario = $_SESSION['usuario'];
    $correo = $_SESSION['correo'];
    $rol = $_SESSION['rol'];
    $contrasena = $_SESSION['contrasena'];

    // Continuar con la lógica deseada utilizando las variables $usuario, $correo y $contrasena
    require_once "../admin_backend/conexion.php";

    $datosusuario = mysqli_query($conn, "SELECT * FROM usuarios WHERE id='$id_usuario'");
    if ($datosusuario) {
        $row = mysqli_fetch_assoc($datosusuario);
        $nombres_actual = $row['nombres'];
        $apellidos_actual = $row['apellidos'];
        $correl_actual = $row['correo'];
        $telefono_actual = $row['telefono'];
        $usuario_actual = $row['usuario'];
        $equipo_actual = $row['equipo'];
        $saldo_actual = $row['saldo'];
        $rol_actual = $row['rol'];

        // Continuar con la lógica deseada utilizando las variables $nombres_actual, $apellidos_actual, $correl_actual, $telefono_actual, $rol_actual y $contrasena_actual
    } else {
        // Error en la consulta
    }
} else {
    // Redirigir a una página en caso de que alguna de las variables de sesión no exista
    echo "<script>
    alert('Por favor inicia sesión para ver el contenido');
    window.location='../admin/login';
    </script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="sitio web para venta de cuentas de streaming">
    <meta name="author" content="jlwebmaster">
    <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">
    <title>Streaming JM</title>
    <!-- Custom fonts for this template-->
    <link href="../admin/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="../admin/css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="styles.css" rel="stylesheet" type="text/css" />
    <style>
        .card {
            height: 100%;
        }
        .card-img-top {
            object-fit: cover;
            height: 200px;
        }
        .card-body {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            align-items: center;
            padding: 1rem;
        }
        .card-title {
            margin-top: 1rem;
        }
        .card-text {
            margin-bottom: 1rem;
        }
        .content-wrapper {
            padding-top: 60px;
            overflow-x: hidden;
        }
    </style>
</head>
<body>
<header class="header fixed-top">
    <a href="../admin/">
        <div class="logo">
            <img src="./Img/Logo.png" alt="Logo de la marca" />
        </div>
    </a>
    <a class="btn" href="https://api.whatsapp.com/send?phone=5216564609548&text=Hola!%20Vengo%20por%20m%C3%A1s%20informaci%C3%B3n%20de%20Streaming%20MJ%20">
        <button>Contactanos</button>
    </a>
    <a style="color:blue;" href="https://api.whatsapp.com/send?phone=5216564609548&text=Hola!%20necesito%20soporte%20pues%20ha%20ocurrido%20el%20siguiente%20error:">
        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="gray" class="bi bi-question-square-fill" viewBox="0 0 16 16">
            <path d="M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm3.496 6.033a.237.237 0 0 1-.24-.247C5.35 4.091 6.737 3.5 8.005 3.5c1.396 0 2.672.73 2.672 2.24 0 1.08-.635 1.594-1.244 2.057-.737.559-1.01.768-1.01 1.486v.105a.25.25 0 0 1-.25.25h-.81a.25.25 0 0 1-.25-.246l-.004-.217c-.038-.927.495-1.498 1.168-1.987.59-.444.965-.736.965-1.371 0-.825-.628-1.168-1.314-1.168-.803 0-1.253.478-1.342 1.134-.018.137-.128.25-.266.25h-.825zm2.325 6.443c-.584 0-1.009-.394-1.009-.927 0-.552.425-.94 1.01-.94.609 0 1.028.388 1.028.94 0 .533-.42.927-1.029.927z"/>
        </svg>
        Soporte
    </a>
    <a href="carrito" style="color:blue;">
        <?php
        $articuloscompra = mysqli_query($conn, "SELECT * FROM carrito WHERE usuario='$id_usuario'");
        if ($articuloscompra) {
            $numeroProductos = mysqli_num_rows($articuloscompra);
            if ($numeroProductos > 0) {
                echo $numeroProductos;
            }
        } else {
            // Error en la consulta
        }
        ?>

        <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="blue" class="bi bi-cart-check" viewBox="0 0 16 16">
            <path d="M11.354 6.354a.5.5 0 0 0-.708-.708L8 8.293 6.854 7.146a.5.5 0 1 0-.708.708l1.5 1.5a.5.5 0 0 0 .708 0l3-3z"/>
            <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1H.5zm3.915 10L3.102 4h10.796l-1.313 7h-8.17zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
        </svg> 
    </a>
</header>
<?php
if (isset($_GET['productoanadido'])) {
    $prodan = $_GET['productoanadido'];
    echo '<script>alert("' . $prodan . '");</script>';
}
?>

<div class="content-wrapper">
    <div class="row">
        <?php
        // Consulta a la tabla tipo_cuenta
        $query = "SELECT id, nombre, imagen, costo, cantidad, estado FROM tipo_cuenta";
        $result = $conn->query($query);

        // Mostrar los resultados
        while ($row = $result->fetch_assoc()) {
            $idcuenta = $row['id'];
            $nombre = $row['nombre'];
            $imagen = $row['imagen'];
            $costo = $row['costo'];
            $cantidad = $row['cantidad'];
            $estado = $row['estado'];

            // Formatear el costo con subfijo de moneda mexicana
            $costo_formateado = '$' . ' ' . number_format($costo, 2, '.', ',') . ' MXN ';

            // Estructura HTML dinámica
            if ($estado == "activo") {
                echo '<div class="col-lg-3 col-md-6 col-sm-6 col-12 mb-4">';
                echo '<div class="card">';
                echo '<img src="' . $imagen . '" alt="' . $nombre . '" class="card-img-top img-fluid" />';
                echo '<div class="card-body">';
                echo '<h5 class="card-title">' . $nombre . '</h5>';
                echo '<p class="card-text"><span style="color: green;">' . $costo_formateado . '</span></p>'; ?>
                <a href="../admin_backend/comprarcuenta?tipocuenta=<?php echo $idcuenta; ?>&usuario=<?php echo $id_usuario; ?>&costo=<?php echo $costo; ?>" class="btn btn-primary">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-cart-plus" viewBox="0 0 16 16">
                        <path d="M9 5.5a.5.5 0 0 0-1 0V7H6.5a.5.5 0 0 0 0 1H8v1.5a.5.5 0 0 0 1 0V8h1.5a.5.5 0 0 0 0-1H9V5.5z"/>
                        <path d="M.5 1a.5.5 0 0 0 0 1h1.11l.401 1.607 1.498 7.985A.5.5 0 0 0 4 12h1a2 2 0 1 0 0 4 2 2 0 0 0 0-4h7a2 2 0 1 0 0 4 2 2 0 0 0 0-4h1a.5.5 0 0 0 .491-.408l1.5-8A.5.5 0 0 0 14.5 3H2.89l-.405-1.621A.5.5 0 0 0 2 1H.5zm3.915 10L3.102 4h10.796l-1.313 7h-8.17zM6 14a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm7 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
                    </svg>&nbsp;&nbsp;Comprar
                </a>
                <?php
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
        }

        // Cierre de la conexión
        $conn->close();
        ?>
    </div>
</div>
</body>
</html>





