<?php
session_start();

if (isset($_SESSION['usuario']) && isset($_SESSION['correo']) && isset($_SESSION['contrasena'])) {
    $id_usuario = $_SESSION['id'];
    $usuario = $_SESSION['usuario'];
    $correo = $_SESSION['correo'];
    $rol = $_SESSION['rol'];
    $contrasena = $_SESSION['contrasena'];

    // Continuar con la lógica deseada utilizando las variables $usuario, $correo y $contrasena
    require_once "../admin_backend/conexion.php";

    $datosusuario = mysqli_query($conn, "SELECT * FROM usuarios WHERE id='$id_usuario'");
    if ($datosusuario) {
        $row = mysqli_fetch_assoc($datosusuario);
        $nombres_actual = $row['nombres'];
        $apellidos_actual = $row['apellidos'];
        $correl_actual = $row['correo'];
        $telefono_actual = $row['telefono'];
        $usuario_actual = $row['usuario'];
        $equipo_actual = $row['equipo'];
        $saldo_actual = $row['saldo'];
        $rol_actual = $row['rol'];

        // Continuar con la lógica deseada utilizando las variables $nombres_actual, $apellidos_actual, $correl_actual, $telefono_actual, $rol_actual y $contrasena_actual
        
        // Consulta INNER JOIN
        $consulta = "SELECT carrito.id AS carritoselecion, carrito.tipo_cuenta AS idcuenta, tipo_cuenta.nombre, carrito.cantidad, carrito.total
                     FROM carrito 
                     INNER JOIN tipo_cuenta ON carrito.tipo_cuenta = tipo_cuenta.id WHERE carrito.usuario=$id_usuario;";
        $resultado = mysqli_query($conn, $consulta);

        if ($resultado) {
            // Almacenar resultados en una tabla HTML
            echo '<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="sitio web para venta de cuentas de streaming">
    <meta name="author" content="jlwebmaster">
    <link rel="shortcut icon" href="img/logo.png" type="image/x-icon">
    <title>Streaming JM</title>
    <!-- Custom fonts for this template-->
    <link href="../admin/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="../admin/css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        img {
            max-width: 150px;
            max-height: 150px;
            object-fit: cover;
            border-radius: 20px 20px 0px 0px;
        }

        /* Estilos para la ventana modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 400px;
            border-radius: 5px;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .form-group input[type="number"] {
            width: 50px;
        }

        .form-group button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <header class="header fixed-top">
        <a href="../admin/">
            <div class="logo">
                <img src="./Img/Logo.png" alt="Logo de la marca" />
            </div>
        </a>
    </header>
    <div class="container text-center">
        <div class="row">
            <div class="col"></div>
            <div class="col text-center">
                <br><br>
                <h3 style="color: blue;">Carrito</h3>
                <br>
                <table class="table">
                    <thead>
                        <tr>
                            <th hidden>ID</th>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Precio</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th></th>
                            <th>Total:</th>
                            <th id="total" colspan="2"></th>
                        </tr>
                        <tr></tr>
                        <tr>
                            <th></th>
                            <th></th>
                            <th><a href="../admin_backend/finalizarcompra?usuario=' . $id_usuario . '">
                            <button style="background-color:blue;color:white;border-style:solid;border-radius:10%;">Finalizar compra</button>
                            </a></th>
                        </tr>
                    </tfoot>
                    <tbody>';

// Variables para almacenar el total de los precios
$totalPrecios = 0;

// Recorrer los resultados de la consulta
while ($fila = mysqli_fetch_assoc($resultado)) {
    $id = $fila['carritoselecion'];
    $nombreCuenta = $fila['nombre'];
    $cantidad = $fila['cantidad'];
    $idcuenta = $fila['idcuenta'];
    $precio = $fila['total'];
    $precioproducto = $precio * $cantidad;

    // Agregar cada fila a la tabla
    echo "<tr>
            <td hidden>$id</td>
            <td>$nombreCuenta</td>
            <td>$cantidad &nbsp;&nbsp;<button onclick='openModal($id)'><i class='fas fa-plus'></i></button></td>
            <td>$precioproducto</td>
            <td><a  href='eliminarcarrito.php?aeliminar=$id'>Eliminar</a></td>
          </tr>";

    // Ventana modal correspondiente a cada fila
    echo "<div id='modal-$id' class='modal'>
            <div class='modal-content'>
                <span class='close' onclick='closeModal($id)'>&times;</span>
                <h3>Seleccionar cantidad</h3>
                <form id='modal-form-$id' method='post' action='../admin_backend/actualizar_carrito.php'>
                    <div class='form-group' hidden>
                        <label for='carrito'>Carrito:</label>
                        <input type='number' id='carrito' name='carrito' value='$id' readonly>
                    </div>
                    <div class='form-group' hidden>
                        <label for='usuario'>Usuario:</label>
                        <input type='number' id='usuario' name='usuario' value='$id_usuario' readonly>
                    </div>
                    <div class='form-group' hidden>
                        <label for='tipo_cuenta'>ID Cuenta:</label>
                        <input type='number' id='tipo_cuenta' name='tipo_cuenta' value='$idcuenta' readonly>
                    </div>
                    <div class='form-group' hidden>
                        <label for='cantidad_actual'>Cantidad actual:</label>
                        <input type='number' id='cantidad_actual' name='cantidad_actual' value='$cantidad' readonly>
                    </div>
                    <div class='form-group'>
                        <label for='cantidad'>Cantidad:</label>
                        <input type='number' id='cantidad' name='cantidad' value='0' min='0'>
                    </div>
                    <div class='form-group'>
                        <button type='submit'>Actualizar carrito</button>
                    </div>
                </form>
            </div>
        </div>";

    // Sumar el precio del producto al total
    $totalPrecios += $precioproducto;
}

// Mostrar el total de los precios en el campo correspondiente
echo '<script>document.getElementById("total").innerHTML = "' . $totalPrecios . '";</script>';

// Cerrar la estructura HTML
echo '</tbody>
    </table>
  </div>
  <div class="col"></div>
</div>
</div>

<script>
    // Función para abrir la ventana modal y asignar el ID del producto
    function openModal(id) {
        var modal = document.getElementById("modal-" + id);
        modal.style.display = "block";

        // Asignar el ID del producto al formulario
        document.getElementById("modal-form-" + id).action = "../admin_backend/actualizar_carrito.php?id=" + id;
    }

    // Función para cerrar la ventana modal
    function closeModal(id) {
        var modal = document.getElementById("modal-" + id);
        modal.style.display = "none";
    }
</script>
</body>
</html>';

        } 
    }
    else {
        // Error en la consulta
        echo "Error: " . mysqli_error($conn);
    }
} 
else {
    // Redirigir a una página en caso de que alguna de las variables de sesión no exista
    echo "<script>
        alert('Por favor inicia sesión para ver el contenido');
        window.location='../admin/login';
        </script>";
    exit();
}
?>
