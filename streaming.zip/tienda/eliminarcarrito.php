<?php
require_once "../admin_backend/conexion.php";
$id = $_GET['aeliminar'];

// Actualizar el campo "estado" a "inactivo" en la base de datos
$borrar = "DELETE FROM carrito WHERE id = $id";

if (mysqli_query($conn, $borrar)) {
    mysqli_close($conn);
    header("Location: carrito.php");
    exit(); // Se agrega exit() para detener la ejecución del script después de la redirección
} else {
    echo "No se pudo eliminar el registro.";
}
?>
