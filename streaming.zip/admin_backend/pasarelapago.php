<?php
require_once("conexion.php");
$id = $_POST['id'];
$nombres = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$saldoactual = $_POST['saldo'];
$saldorecarga = $_POST['saldo_recarga'];

$nuevosaldo = $saldoactual + $saldorecarga;

// SDK de Mercado Pago
require __DIR__ .  '/vendor/autoload.php';



// Agrega credenciales
MercadoPago\SDK::setAccessToken('TEST-5345425724957488-071614-3d578f7ae27a3d161c56cd2eedb93deb-44109772');

// Crea un objeto de preferencia
$preference = new MercadoPago\Preference();


// Crea un ítem en la preferencia
$item = new MercadoPago\Item();
$item->id= '2093';
$item->title = 'JM streaming';
$item->quantity = 1;
$item->unit_price =$saldorecarga;
$item->currency_id = "MXN";
$preference->items = array($item);

//agregamos  las preferencias  de url

$preference->back_urls=array(
    "success"=>"pagoexito?nuevosaldo=$nuevosaldo&usuario=$id",
    "failure"=>"../admin/recargar?fallo=el%20pago%20fallo%20trata%20de%20pagar%20nuevamente"
);

$preference->auto_return="approved";
$preference->binary_mode=true;



$preference->save();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pagar</title>
    <script src="https://sdk.mercadopago.com/js/v2">
    // SDK MercadoPago.js V2
</script>

</head>
<body>

<script>
  const mp = new MercadoPago('TEST-69af6c27-35c3-4365-b6c9-ab1100f26f5d', {
    locale: 'es-CO'
  });

  mp.checkout({
    preference: {
      id: '<?php  echo  $preference->id; ?>'
    },
    autoOpen: true, // Habilita la apertura automática del Checkout Pro
  });
</script>