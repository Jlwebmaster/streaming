<?php
require_once("conexion.php");

$usuario = $_GET['usuario'];
$tipo_cuenta = $_GET['tipocuenta'];
$costo = $_GET['costo'];
$cantidad = 1;

// Realizar la inserción en la base de datos
$sql = "INSERT INTO carrito (tipo_cuenta, cantidad, total, usuario) 
VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param('iiis', $tipo_cuenta, $cantidad, $costo, $usuario);

if ($stmt->execute()) {
    header("location:../tienda?productoanadido=el%20producto%20se%20ha%20añadido%20correctamente%20al%20carrito%20de%20compras");
} else {
    header("location:../admin/usuarios?productonoanadido=ha%20ocurrido%20un%20error%20al%20añadir%20el%20producto%20por%20favor%20trata%20nuevamente");
}

$stmt->close();
$conn->close();
?>
