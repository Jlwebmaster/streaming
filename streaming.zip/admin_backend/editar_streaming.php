<?php
require_once "conexion.php";

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$imagen = $_POST['imagen'];
$costo = $_POST['costo'];
$cantidad= $_POST['cantidad'];


// Realizar la actualización en la base de datos
$sql = "UPDATE tipo_cuenta SET nombre = ?, imagen = ?, costo = ?, cantidad = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ssssi', $nombre, $imagen, $costo, $cantidad, $id);

if ($stmt->execute()) {
 header("location: ../admin/inventario?usuarioactualizado=el%20producto%20se%20ha%20actualizado%20correctamente");
} else {
    header("location: ../admin/inventario?usuarionoactualizado=el%20producto%20no%20se%20ha%20actualizado");
}
?>


