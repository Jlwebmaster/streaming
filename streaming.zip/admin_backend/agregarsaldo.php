<?php
require_once("conexion.php");
$usuario = $_POST['usuario'];
$saldoseleccionado = $_POST['saldoactual'];
if ($saldoseleccionado == NULL) {
    $saldoactual = 0;
} else {
    $saldoactual = $saldoseleccionado;
}

echo $saldoactual;
$saldorecargar = $_POST['saldorecargar'];

$nuevosaldo = $saldoactual + $saldorecargar;

// Realizar la actualización en la base de datos

$sql = "UPDATE usuarios SET saldo = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ii', $nuevosaldo, $usuario);
if ($stmt->execute()) {
    header("location:../admin/usuarios?saldoactualizado=el%20saldo%20se%20ha%20actualizado%20corectamente");
    
} else {
    header("location:../admin/usuarios?saldonoactualizado=ha%20ocurrido%20un%20error%20al%20actualizar%20el%20saldo%20por%20favor%20trata%20nuevamente");
}

?>

