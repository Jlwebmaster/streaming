<?php
require_once("conexion.php");

$nombres = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$telefono = $_POST['telefono'];
$correo = $_POST['correo'];
$contrasena = md5($_POST['contrasena']);
$rol = $_POST['rol'];

if ($rol == 1) {
    header("location:../admin/register");
}

// Verificar si el correo ya está registrado
$consulta = "SELECT correo FROM usuarios WHERE correo = '$correo'";
$resultado = mysqli_query($conn, $consulta);

if (mysqli_num_rows($resultado) > 0) {
    // El correo ya está registrado
    header("location: ../admin/register?correoregistrado=El%20correo%20electrónico%20ya%20tiene%20una%20cuenta.%20Por%20favor,%20intenta%20con%20otro%20correo.");
} else {
    // Generar nombre de usuario único
    $nombreUsuario = generarNombreUsuario($nombres, $apellidos);
    
    // Insertar datos en la tabla de usuarios
    $insertar = "INSERT INTO usuarios (nombres, apellidos, telefono, correo, contrasena, usuario,rol) 
                 VALUES ('$nombres', '$apellidos', '$telefono', '$correo', '$contrasena', '$nombreUsuario', '$rol')";

    if (mysqli_query($conn, $insertar)) {
        // Enviar correo con los detalles de la cuenta
        $asunto = "¡Felicidades! Tu cuenta se ha creado exitosamente";
        $mensaje = "Hola $nombres,\n\n";
        $mensaje .= "Te informamos que se ha creado exitosamente tu cuenta en nuestro sitio.\n";
        $mensaje .= "Recuerda que tu nombre de usuario es: $nombreUsuario\n";
        $mensaje .= "Tu contraseña es: $contrasena\n\n";
        $mensaje .= "Puedes acceder a tu cuenta en example.com\n\n";
        $mensaje .= "Gracias por registrarte. ¡Bienvenido!\n";
        
        // Enviar correo electrónico
        $remitente = "templet1993@gmail.com";
        $cabeceras = "From: $remitente";
        
        if (mail($correo, $asunto, $mensaje, $cabeceras)) {
            header("location: ../admin/register?registroexitoso=Se%20ha%20registrado%20exitosamente");
        } else {
            echo "Error al enviar el correo.";
        }
    } else {
        header("location: ../admin/register?registrofallido=20ha%20ocurrido%20un%20error%20al%20registrar%20el%20usuario");
    }
}

// Cerrar la conexión
mysqli_close($conn);

// Función para generar un nombre de usuario único con el tiempo
function generarNombreUsuario($nombres, $apellidos) {
    $nombres = strtolower($nombres);
    $apellidos = strtolower($apellidos);
    
    // Eliminar espacios y caracteres especiales de los nombres y apellidos
    $nombres = preg_replace('/[^a-z0-9]+/', '', $nombres);
    $apellidos = preg_replace('/[^a-z0-9]+/', '', $apellidos);
    
    // Obtener la marca de tiempo actual
    $timestamp = time();
    
    // Concatenar nombres, apellidos y marca de tiempo
    $nombreUsuario = $nombres . $apellidos . $timestamp;
    
    // Verificar si el nombre de usuario ya existe en la tabla de usuarios
    global $conn;
    $consulta = "SELECT usuario FROM usuarios WHERE usuario = '$nombreUsuario'";
    $resultado = mysqli_query($conn, $consulta);
    
    $contador = 1;
    while (mysqli_num_rows($resultado) > 0) {
        // Agregar un número al final del nombre de usuario
        $nombreUsuario = $nombres . $apellidos . $timestamp . $contador;
        
        // Verificar nuevamente si el nombre de usuario ya existe
        $consulta = "SELECT usuario FROM usuarios WHERE usuario = '$nombreUsuario'";
        $resultado = mysqli_query($conn, $consulta);
        
        $contador++;
    }
    
    return $nombreUsuario;
}

?>