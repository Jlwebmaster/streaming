<?php
require_once "conexion.php";
$usuario = $_POST['usuario'];
$tipo_cuenta = $_POST['tipo_cuenta'];
$cantidad_actual = $_POST['cantidad_actual'];
$nueva_cantidad = $_POST['cantidad'];
$carrito = $_POST['carrito'];
// Realizar la suma de la cantidad actual y la nueva cantidad
$cantidad_total = $cantidad_actual + $nueva_cantidad;

// Actualizar el campo 'cantidad' en la tabla 'carrito'
$query = "UPDATE carrito SET cantidad = $cantidad_total WHERE usuario = $usuario AND tipo_cuenta = $tipo_cuenta  AND id=$carrito";
$result = mysqli_query($conn, $query);

// Verificar si la actualización fue exitosa
if ($result) {
    header("Location: ../tienda/carrito?actualizado=se%20a%20añadido%20la%20nueva%20cantidad");
    exit();
} else {
    header("Location: ../tienda/carrito?error=ha%20ocurriso%20un%20error%20por%20trata%20nuevamente");
    exit();
}


?>
