<?php
require_once("conexion.php");

$correo = $_POST["correo"];

// Verificar si el correo está registrado
$consulta = "SELECT * FROM usuarios WHERE correo = '$correo'";
$resultado = mysqli_query($conn, $consulta);

if (mysqli_num_rows($resultado) > 0) {
    $usuario = mysqli_fetch_assoc($resultado);
    $nombres = $usuario['nombres'];

    // Generar nueva contraseña
    $nuevaContrasena = generarContrasena();

    // Encriptar la nueva contraseña
    $nuevaContrasenaEncriptada = md5($nuevaContrasena);

    // Actualizar la contraseña en la tabla de usuarios
    $actualizar = "UPDATE usuarios SET contrasena = '$nuevaContrasenaEncriptada' WHERE correo = '$correo'";
    mysqli_query($conn, $actualizar);

    // Enviar correo con la nueva contraseña
    $asunto = "Recuperación de contraseña";
    $mensaje = "Hola $nombres,\n\n";
    $mensaje .= "Hemos recibido una solicitud para restablecer tu contraseña.\n";
    $mensaje .= "Tu nueva contraseña es: $nuevaContrasena\n\n";
    $mensaje .= "Recuerda cambiar tu contraseña después de iniciar sesión.\n\n";
    $mensaje .= "Saludos,\n";
    $mensaje .= "El equipo de ejemplo";

    $remitente = "templet1993@gmail.com";
    $cabeceras = "From: $remitente";

    if (mail($correo, $asunto, $mensaje, $cabeceras)) {
        header("location: ../admin/forgot-password.php?exito=Se%20ha%20enviado%20la%20nueva%20contraseña%20a%20tu%20correo%20electrónico");
    } else {
        echo "Error al enviar el correo.";
    }
} else {
    header("location: ../admin/forgot-password?error=El%20correo%20no%20está%20registrado%20en%20el%20sistema");
}

// Función para generar una contraseña aleatoria
function generarContrasena($longitud = 8) {
    $caracteres = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $contrasena = '';

    for ($i = 0; $i < $longitud; $i++) {
        $indice = mt_rand(0, strlen($caracteres) - 1);
        $contrasena .= $caracteres[$indice];
    }

    return $contrasena;
}
?>
