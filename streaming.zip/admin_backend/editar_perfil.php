<?php
require_once "conexion.php";

$id = $_POST['id'];
$nombres = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$telefono = $_POST['telefono'];
$correo = $_POST['correo'];
$usuario = $_POST['usuario'];
$rol = $_POST['rol'];

// Verificar si el usuario ya está registrado
$sql_verificar = "SELECT COUNT(*) FROM usuarios WHERE usuario = ?";
$stmt_verificar = $conn->prepare($sql_verificar);
$stmt_verificar->bind_param('s', $usuario);
$stmt_verificar->execute();
$stmt_verificar->bind_result($count);
$stmt_verificar->fetch();
$stmt_verificar->close();

if ($count > 0) {
    header("location: ../admin/perfil?usuarioyaexiste=El usuario ya está registrado. Por favor, elija otro nombre de usuario.");
    exit();
}

// Realizar la actualización en la base de datos
$sql = "UPDATE usuarios SET nombres = ?, apellidos = ?, telefono = ?, usuario = ?, correo = ?, rol = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ssssssi', $nombres, $apellidos, $telefono, $usuario, $correo, $rol, $id);

if ($stmt->execute()) {
    header("location: ../admin/perfil?usuarioactualizado=El usuario se ha actualizado correctamente.");
} else {
    header("location: ../admin/perfil?usuarionoactualizado=El usuario no se ha actualizado. Por favor, intenta nuevamente.");
}
$stmt->close();
$conn->close();


?>


