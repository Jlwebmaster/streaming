<?php
require_once("conexion.php");

$nombre = $_POST['nombre'];
$imagen = $_POST['imagen'];
$costo = $_POST['costo'];
$cantidad = $_POST['cantidad'];




    // Insertar datos en la tabla de usuarios
    $insertar = "INSERT INTO tipo_cuenta (nombre, imagen, costo, cantidad) 
                 VALUES ('$nombre', '$imagen', '$costo', '$cantidad')";

    if (mysqli_query($conn, $insertar)) {
       
        
       
            header("location: ../admin/nuevostreaming?registroexitoso=Se%20ha%20registrado%20exitosamente%20la%20cuenta%2oen%20el%20sistema");
       
    } else {
        header("location: ../admin/nuevostreaming?registrofallido=20ha%20ocurrido%20un%20error%20al%20registrar%20la%20cuenta%20en%20el%20sistema");
    }


// Cerrar la conexión
mysqli_close($conn);


    
   

?>