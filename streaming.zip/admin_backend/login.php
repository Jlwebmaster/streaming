<?php
session_start();
require_once "conexion.php";
// Obtener los parámetros enviados por POST
$usuario = $_POST['usuario'];
$contrasena =md5( $_POST['contrasena']);


// Consultar si el usuario existe en la base de datos
$sql = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // El usuario existe, verificar la contraseña
    $row = $result->fetch_assoc();
    if ($row['contrasena'] == $contrasena) {
        // La contraseña es correcta, continuar con la lógica deseada
        // Por ejemplo, redireccionar a una página de inicio de sesión exitosa   
        $_SESSION['id'] = $row['id'];
        $_SESSION['nombres'] = $row['nombres'];
        $_SESSION['apellidos'] = $row['apellidos'];
        $_SESSION['correo'] = $row['correo'];
        $_SESSION['telefono'] = $row['telefono'];
        $_SESSION['usuario'] = $row['usuario'];
        $_SESSION['contrasena'] = $row['contrasena'];
        $_SESSION['equipo'] = $row['equipo'];
        $_SESSION['saldo'] = $row['saldo'];
        $_SESSION['rol'] = $row['rol'];
       

        header("Location: ../admin/");
      
    } else {
        // Contraseña incorrecta, redireccionar con mensaje de error
        header("Location: ../admin/login?continc=contraseña%20incorrecta");
        exit();
    }
} else {
    // Usuario incorrecto, redireccionar con mensaje de error
    header("Location: ../admin/login?uinc=usuario%20incorrecto");
    exit();
}

// Cerrar la conexión
$conn->close();
?>
