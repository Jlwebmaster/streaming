<?php
require_once "conexion.php";

$id = $_POST['id'];
$nombres = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$telefono = $_POST['telefono'];
$correo = $_POST['correo'];
$rol = $_POST['rol'];

// Realizar la actualización en la base de datos
$sql = "UPDATE usuarios SET nombres = ?, apellidos = ?, telefono = ?, correo = ?, rol = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('sssssi', $nombres, $apellidos, $telefono, $correo, $rol, $id);

if ($stmt->execute()) {
 header("location: ../admin/usuarios?usuarioactualizado=el%20usuario%20se%20ha%20actualizado%20correctamente");
} else {
    header("location: ../admin/usuarios?usuarionoactualizado=el%20usuario%20no%20se%20ha%20actualizado");
}
?>


