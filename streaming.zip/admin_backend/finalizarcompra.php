<?php
session_start();

if (isset($_SESSION['usuario']) && isset($_SESSION['correo']) && isset($_SESSION['contrasena'])) {
    $id_usuario = $_SESSION['id'];
    $usuario = $_SESSION['usuario'];
    $correo = $_SESSION['correo'];
    $rol = $_SESSION['rol'];
    $contrasena = $_SESSION['contrasena'];
    


    // Continuar con la lógica deseada utilizando las variables $usuario, $correo y $contrasena
    require_once "../admin_backend/conexion.php";

    $datosusuario = mysqli_query($conn, "SELECT * FROM usuarios WHERE id='$id_usuario'");
    if ($datosusuario) {
        $row = mysqli_fetch_assoc($datosusuario);
        $nombres_actual = $row['nombres'];
        $apellidos_actual = $row['apellidos'];
        $correl_actual = $row['correo'];
        $telefono_actual = $row['telefono'];
        $usuario_actual = $row['usuario'];
        $equipo_actual = $row['equipo'];
        $saldo_actual = $row['saldo'];
        $rol_actual = $row['rol'];

        // Continuar con la lógica deseada utilizando las variables $nombres_actual, $apellidos_actual, $correl_actual, $telefono_actual, $rol_actual y $contrasena_actual

        // Consulta INNER JOIN
        $consulta = "SELECT carrito.id AS carritoseleccion, carrito.tipo_cuenta AS idcuenta, tipo_cuenta.nombre, carrito.cantidad, carrito.total
                     FROM carrito 
                     INNER JOIN tipo_cuenta ON carrito.tipo_cuenta = tipo_cuenta.id WHERE carrito.usuario=$id_usuario;";
        $resultado = mysqli_query($conn, $consulta);

        if ($resultado) {
            // Variable para almacenar el total de los precios
            $totalPrecios = 0;

            // Recorrer los resultados de la consulta
            while ($fila = mysqli_fetch_assoc($resultado)) {
                $id = $fila['carritoseleccion'];
                $nombreCuenta = $fila['nombre'];
                $cantidad = $fila['cantidad'];
                $idcuenta = $fila['idcuenta'];
                $precio = $fila['total'];
                $precioproducto = $precio * $cantidad;

                // Sumar el precio del producto al total
                $totalPrecios += $precioproducto;
            }

            // Comparar el saldo actual con el total de los precios
            if ($saldo_actual >= $totalPrecios) {
                $nuevosaldo = $saldo_actual - $totalPrecios;

                // Realizar la consulta UPDATE para actualizar el saldo
                $actualizarSaldo = mysqli_query($conn, "UPDATE usuarios SET saldo=$nuevosaldo WHERE id='$id_usuario'");

                if ($actualizarSaldo) {
                    // Recorrer los resultados de la consulta nuevamente
                    mysqli_data_seek($resultado, 0);
                    while ($fila = mysqli_fetch_assoc($resultado)) {
                        $id = $fila['carritoseleccion'];
                        $nombreCuenta = $fila['nombre'];
                        $cantidad = $fila['cantidad'];
                        $idcuenta = $fila['idcuenta'];
                        $precio = $fila['total'];
                        $precioproducto = $precio * $cantidad;

                        // Sumar el precio del producto al total
                        $totalPrecios += $precioproducto;

                        $consultarstream = mysqli_query($conn, "SELECT * FROM tipo_cuenta WHERE id='$idcuenta'");

                        // Verificar si la consulta se realizó correctamente
                        if ($consultarstream) {
                            // Recorrer los resultados de la consulta
                            while ($fila = mysqli_fetch_assoc($consultarstream)) {
                                $idStream = $fila['id'];
                                $cantidadStream = $fila['cantidad'];
                                $estadoStream = $fila['estado'];

                                // Restar la cantidad de la tabla "tipo_cuenta"
                                if ($cantidadStream >= $cantidad) {
                                    $cantidadStream -= $cantidad;

                                    // Realizar la consulta UPDATE para actualizar la cantidad
                                    $actualizarCantidad = mysqli_query($conn, "UPDATE tipo_cuenta SET cantidad=$cantidadStream WHERE id='$idStream'");

                                    if ($actualizarCantidad) {
                                        $actualizarventas = mysqli_query($conn, "UPDATE cuentas_vendidas SET usuario = '$id_usuario', estado = 'agotado' WHERE tipo_cuenta = '$idcuenta' LIMIT $cantidad");
                                    
                                        if ($actualizarventas) {
                                            // Realizar el select de la tabla cuentas_vendidas
                                            $selectCuentasVendidas = mysqli_query($conn, "SELECT id, correo, contraseña FROM cuentas_vendidas WHERE usuario = '$id_usuario'");
                                    
                                            if ($selectCuentasVendidas) {
                                                $correoregistrado = ''; // Variable para almacenar los datos de las filas
                                    
                                                // Recorrer los resultados del select
                                                while ($fila = mysqli_fetch_assoc($selectCuentasVendidas)) {
                                                    $id = $fila['id'];
                                                    $correo = $fila['correo'];
                                                    $contraseña = $fila['contraseña'];
                                    
                                                    // Concatenar los datos de las filas
                                                    $correoregistrado .= "ID: $id<br>Correo: $correo<br>Contraseña: $contraseña<br><br>";
                                                }
                                    
                                                // Enviar correo electrónico
                                                // Utiliza tu propia lógica o librería para enviar el correo
                                                // Aquí tienes un ejemplo básico utilizando la función mail de PHP
                                                $to = $correoregistrado;
                                                $subject = " admin JM stream";
                                                $message = "Los datos de aceso son:<br><br>correo: $correoregistrado
                                                <br>contraseña:$contraseña";
                                                $headers = "MIME-Version: 1.0" . "\r\n";
                                                $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                                                $headers .= "From: admin@streamingmj.online " . "\r\n"; // Reemplaza con tu dirección de correo
                                    
                                                // Enviar el correo
                                                mail($to, $subject, $message, $headers);
                                    
                                                $vaciarcarrito = mysqli_query($conn, "DELETE FROM carrito WHERE usuario=$id_usuario");

                                                if ($vaciarcarrito) {
                                                    header("location:../tienda?exitocompra=la%20compra%20se%20ha%20realizado%20de%20manera%20exitosa");
                                                } else {
                                                    echo "No se ha podido vaciar el carrito.";
                                                }
                                                
                                            } else {
                                                echo "No se pudieron obtener los datos de la tabla cuentas_vendidas.";
                                            }
                                        } else {
                                            echo "No se pudieron actualizar los campos en la tabla cuentas_vendidas.";
                                        }
                                    }
                                    
                                    
                                    else {
                                        echo "Error al actualizar la tabla 'tipo_cuenta'.";
                                    }
                                } else {
                                    echo "No puedes comprar más cuentas de las disponibles.";
                                }
                            }
                        } else {
                            echo "Error al consultar la tabla 'tipo_cuenta'.";
                        }
                    }
                } else {
                    echo "Error al actualizar el saldo.";
                }
            } else {
                echo "Saldo insuficiente. Por favor, recargue su cuenta.";
            }
        }
    } else {
        // Redirigir a una página en caso de que alguna de las variables de sesión no exista
        echo "<script>
            alert('Por favor inicia sesión para ver el contenido');
            window.location='../admin/login';
            </script>";
        exit();
    }
} else {
    // Redirigir a una página en caso de que alguna de las variables de sesión no exista
    echo "<script>
        alert('Por favor inicia sesión para ver el contenido');
        window.location='../admin/login';
        </script>";
    exit();
}
?>