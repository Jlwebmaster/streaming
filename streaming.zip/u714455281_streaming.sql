-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 20-07-2023 a las 01:22:39
-- Versión del servidor: 10.5.19-MariaDB-cll-lve
-- Versión de PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `u714455281_streaming`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrito`
--

CREATE TABLE `carrito` (
  `id` int(11) NOT NULL,
  `tipo_cuenta` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `carrito`
--

INSERT INTO `carrito` (`id`, `tipo_cuenta`, `cantidad`, `total`, `usuario`) VALUES
(25, 1, 1, 25, 8),
(47, 4, 1, 20, 11);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuentas_vendidas`
--

CREATE TABLE `cuentas_vendidas` (
  `id` int(11) NOT NULL,
  `usuario` int(11) DEFAULT NULL,
  `tipo_cuenta` int(11) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `contraseña` varchar(100) NOT NULL,
  `pin` varchar(100) DEFAULT NULL,
  `estado` varchar(100) NOT NULL DEFAULT 'disponible'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `cuentas_vendidas`
--

INSERT INTO `cuentas_vendidas` (`id`, `usuario`, `tipo_cuenta`, `correo`, `contraseña`, `pin`, `estado`) VALUES
(11, 11, 1, 'joshua@gmail.com', 'cello7223', '12345', 'agotado'),
(12, 8, 3, 'pancho@villa.com', 'cello7223', '1245', 'agotado'),
(16, NULL, 1, 'prueba1@gmail.com', 'contraseña: cello7223\r\nPerfil: P1', '1245', 'disponible'),
(17, NULL, 1, 'netflix12@gmail.com', 'cello7334', '5421', 'disponible'),
(18, NULL, 1, 'hotmal@gmail.com', 'cello7223', '2154', 'disponible'),
(19, NULL, 1, 'pruebareal@gmail.com', 'cello7223', '1245', 'disponible'),
(20, NULL, 1, 'fgdfgd@kdjfkd.com', 'jdjdj', '5454', 'disponible'),
(21, NULL, 1, 'guillermodd@gmail.com', 'cello7223', '8754', 'disponible');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mercadopagos`
--

CREATE TABLE `mercadopagos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `credencial` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mercadopagos`
--

INSERT INTO `mercadopagos` (`id`, `nombre`, `credencial`) VALUES
(1, 'public_key', 'TEST-69af6c27-35c3-4365-b6c9-ab1100f26f5d'),
(2, 'acess_token', 'TEST-5345425724957488-071614-3d578f7ae27a3d161c56cd2eedb93deb-44109772');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `estado` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`id`, `nombre`, `estado`) VALUES
(1, 'administrador', 'activo'),
(2, 'nivel_1', 'activo'),
(3, 'nivel_2', 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_cuenta`
--

CREATE TABLE `tipo_cuenta` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `imagen` varchar(200) NOT NULL,
  `costo` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `estado` varchar(100) NOT NULL DEFAULT 'activo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipo_cuenta`
--

INSERT INTO `tipo_cuenta` (`id`, `nombre`, `imagen`, `costo`, `cantidad`, `estado`) VALUES
(1, 'netflix1', 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Netflix_logo.svg/1200px-Netflix_logo.svg.png', 25, 0, 'activo'),
(2, 'disney', '', 15, 10, 'inactivo'),
(3, 'porn hub', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTbJlAZDwYr2KM6HL6XyOANT6hcHfJFPayoWA&usqp=CAU', 20, 0, 'inactivo'),
(4, 'Youtube premium', 'https://i.blogs.es/73dec2/youtube/375_142.webp', 20, 24, 'activo'),
(5, 'hbo +', 'https://cdn.hobbyconsolas.com/sites/navi.axelspringer.es/public/media/image/2021/11/logo-hbo-max-2538085.jpg?tf=640x', 23, 0, 'activo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombres` varchar(100) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `contrasena` varchar(100) NOT NULL,
  `equipo` varchar(100) NOT NULL DEFAULT 'uno',
  `saldo` decimal(10,2) DEFAULT NULL,
  `rol` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombres`, `apellidos`, `correo`, `telefono`, `usuario`, `contrasena`, `equipo`, `saldo`, `rol`) VALUES
(8, 'Josue', 'Zepeda', 'celloguitarra2@outlook.es', '7221197505', 'josuezepeda1689791572', 'e005d3f6002e81f09558db7611cb7297', 'uno', '170.00', 1),
(9, 'josue', 'zepeda2', 'joshua2cello@gmail.com', '7221197505', 'josuezepeda21689801549', 'e005d3f6002e81f09558db7611cb7297', 'uno', NULL, 2),
(10, 'miguel', 'rios', 'jhsjshs@gmail.com', '7221197505', 'miguel', 'e005d3f6002e81f09558db7611cb7297', 'uno', '900.00', 2),
(11, 'usuario de ', 'pruebas', 'templet1993@gmail.com', '3185700785', 'prueba', 'd2ae4fcbf562a73821a2b6838947728f', 'uno', '213021.00', 1),
(12, 'bisbi', 'rudolfo', 'bisbi@gmail.com', '31544332909', 'bisbirudolfo1689812814', '827ccb0eea8a706c4c34a16891f84e7b', 'uno', NULL, 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carrito`
--
ALTER TABLE `carrito`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `cuentas_vendidas`
--
ALTER TABLE `cuentas_vendidas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `usuario` (`usuario`),
  ADD KEY `tipo_cuenta` (`tipo_cuenta`);

--
-- Indices de la tabla `mercadopagos`
--
ALTER TABLE `mercadopagos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipo_cuenta`
--
ALTER TABLE `tipo_cuenta`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `usuario` (`usuario`),
  ADD UNIQUE KEY `correo` (`correo`),
  ADD KEY `rol` (`rol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carrito`
--
ALTER TABLE `carrito`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT de la tabla `cuentas_vendidas`
--
ALTER TABLE `cuentas_vendidas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `mercadopagos`
--
ALTER TABLE `mercadopagos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `rol`
--
ALTER TABLE `rol`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tipo_cuenta`
--
ALTER TABLE `tipo_cuenta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `cuentas_vendidas`
--
ALTER TABLE `cuentas_vendidas`
  ADD CONSTRAINT `fk_tipo_cuenta` FOREIGN KEY (`tipo_cuenta`) REFERENCES `tipo_cuenta` (`id`),
  ADD CONSTRAINT `fk_usuarios` FOREIGN KEY (`usuario`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_rol` FOREIGN KEY (`rol`) REFERENCES `rol` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
