<?php
// Redireccionar a otra página
header("Location: admin/login");
exit(); // Asegurarse de que el código se detenga después de la redirección
?>
