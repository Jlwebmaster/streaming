<?php
require_once "../admin_backend/conexion.php";
$id = $_GET['id'];

// Eliminar el usuario de la base de datos
$sql = "DELETE FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id);

if ($stmt->execute()) {
    header("location: usuarios ");
} else {
    header("location: usuarios ");
}
?>
