<?php
require_once("../admin_backend/conexion.php");

$usr=$_GET['usr'];


$consultarsaldo = mysqli_query($conn, "SELECT * FROM usuarios WHERE id=$usr;");
$usuariologeado= mysqli_fetch_assoc($consultarsaldo);

$idusr=$usuariologeado['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="sitio web para venta de cuentas de streaming">
    <meta name="author" content="jlwebmaster">
<link rel="shortcut icon" href="img/logo.png" type="image/x-icon">

    <title>Streaming JM</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>
<body>

<div class="container text-center">
  <div class="row">
    <div class="col">
     
    </div>
    <div class="col">
        <br><br>
        <h6  style="color:blue;"><?php  echo $usuariologeado['nombres']." ".$usuariologeado['apellidos'];  ?></h6>
        <br>
    <form   action="../admin_backend/agregarsaldo.php" method="post">
    <div class="mb-3" hidden>
    <label for="usuario" class="form-label">usuario</label>
    <input type="number" class="form-control"  value="<?php  echo $usuariologeado['id'];?>" id="usuario" aria-describedby="emailHelp"  name="usuario"  readonly>
  </div>
  <div class="mb-3">
    <label for="saldoactual" class="form-label">Saldo actual</label>
    <input type="number" class="form-control"  value="<?php  echo $usuariologeado['saldo'];?>" id="saldoactual" aria-describedby="emailHelp"  name="saldoactual"  readonly>
  </div>
  <div class="mb-3">
    <label for="saldorecargar" class="form-label">agregar saldo</label>
    <input type="number" class="form-control" min="0"  id="saldorecargar" aria-describedby="emailHelp"  name="saldorecargar"  required>
  </div>
  <input type="submit" class="btn btn-primary" value="Recargar"></input>
</form>
    </div>
    <div class="col">

    </div>
  </div>
</div>
    
</body>
</html>

