<?php
require_once "../admin_backend/conexion.php";
$id = $_GET['id'];

// Actualizar el campo "estado" a "inactivo" en la base de datos
$sql = "UPDATE tipo_cuenta SET estado = 'inactivo' WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id);

if ($stmt->execute()) {
    header("location: inventario");
} else {
    header("location: inventario");
}
?>

